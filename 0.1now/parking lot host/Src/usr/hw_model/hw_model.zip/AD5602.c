#include "AD5602.h"
#include "systick.h"
#include <stdio.h>
#define AD_DA_REF 2960
uint8_t AD5602_Add = 0x1E;


void RFPowerON1(uint16_t x)
{

    uint8_t data1,data2;
	  uint32_t temp;
		
		printf("RFPowerON AD5602 ��ʼ��\n");
	  temp=x*255/AD_DA_REF;
	  temp=(uint8_t)temp;
	  data1=0x0f&(temp>>4);
	  data2=0xf0&(temp<<4);
	  //Clr_ASK_DATA();
	  I2C_Write(I2C1, AD5602_Add, data1, &data2, 1);
    Delay_ms(1);
		printf("RFPowerON AD5602 ����\n");
}

void RFPowerOFF1(void)
{
    uint8_t data1,data2;
	  data1=0x00;
	  data2=0x00;
		printf("RFPowerOFF AD5602 ��ʼ��\n");
	  I2C_Write(I2C1, AD5602_Add, data1, &data2, 1);
		printf("RFPowerOFF AD5602 ����\n");
}
