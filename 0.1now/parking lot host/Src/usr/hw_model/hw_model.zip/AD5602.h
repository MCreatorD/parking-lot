#ifndef _AD5602_H_
#define _AD5602_H_

#include "stm32f2xx.h"
#include "i2c.h"


#define PA_POWER  2960

	#ifdef __cplusplus
	 extern "C" {
	#endif

			void RFPowerON1(uint16_t x);
			void RFPowerOFF1(void);
	#ifdef __cplusplus
	}
	#endif	

#endif
